package com.paxcel.demoCoreModule.dto;

import org.springframework.beans.factory.annotation.Autowired;

public class UserDTO{

	private long accountId;
	private String name;

	private double balance;

	private int age;

	private String gender;

	private String username;

	private String password;

	private long accountNo;
	
	@Autowired
   private AddressDTO addressDTO;


	public AddressDTO getAddressDTO() {
	return addressDTO;
}
public void setAddressDTO(AddressDTO addressDTO) {
	this.addressDTO = addressDTO;
}
	public int getAge() {
	    	return age;
	    }
	    public String getName() {
	        return name;
	    }

	    public double getBalance() {
	        return balance;
	    }
	    
	    public String getGender() {
	    	return gender;
	    }
	    public void setName( String name) {
	        this.name = name;
	    }
	    
	    public void setGender( String gender) {
	    	this.gender = gender;
	    }
	    public void setBalance(double balance) {
	        this.balance = balance;
	    }
	    public void setAge(int age) {
	    	this.age =age;
	    }
		public String getUsername() {
			// TODO Auto-generated method stub
			return username;
		}
		public String getPassword() {
			// TODO Auto-generated method stub
			return password;
		}
		public void setUsername(String username) {
			// TODO Auto-generated method stub
			this.username=username;
			
		}
		public void setPassword(String password) {
			// TODO Auto-generated method stub
			this.password=password;
		}
		
		public long getAccountId() {
			return accountId;
		}
		public void setAccountId(long accountId) {
			this.accountId = accountId;
		}
	
		 public long getAccountNo() {
				return accountNo;
			}
			public void setAccountNo(long accountNo) {
				this.accountNo = accountNo;
			}
		
}

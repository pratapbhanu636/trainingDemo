package com.paxcel.demoCoreModule.converter;

import org.springframework.stereotype.Component;

import com.paxcel.demoCoreModule.dto.FileDTO;

import com.paxcel.demoDaoModule.domain.FileInfo;


@Component
public class FileConvertor {
	public FileDTO convertToDto(FileInfo fileInfo) {
		FileDTO fileDTO = new FileDTO();
        fileDTO.setAccountId(fileInfo.getAccountId());
        fileDTO.setFileName(fileInfo.getFileName());
        fileDTO.setData(fileInfo.getData());
	

		return fileDTO;
	}
     
	 public FileInfo convertToBean(FileDTO fileDTO)
	 {
		 FileInfo fileInfo =new FileInfo();
		 fileInfo.setAccountId(fileDTO.getAccountId());
		 fileInfo.setFileName(fileDTO.getFileName());
		 fileInfo.setData(fileDTO.getData());
		 
		 
		 return fileInfo;
	 }

}

package com.paxcel.demoCoreModule.dto;

public class BalanceDTO {

	private long accountId;
	private double addAmount;
	private double withdrawAmount;
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public double getAddAmount() {
		return addAmount;
	}

	public void setAddAmount(double addAmount) {
		this.addAmount = addAmount;
	}

	public double getWithdrawAmount() {
		return withdrawAmount;
	}

	public void setWithdrawAmount(double withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	private double balance;
}

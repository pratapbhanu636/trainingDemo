package com.paxcel.demoCoreModule.services;

public interface FileParser {
	
	void parse();

}

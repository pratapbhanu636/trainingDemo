package com.paxcel.demoCoreModule.services.impl;

import org.springframework.stereotype.Service;

import com.paxcel.demoCoreModule.services.FileParser;

@Service("csv")
public class CSVFileParserImpl implements FileParser{

	public void parse() {
		System.out.println("CSVFileParserImpl");
		
	}
	
	

}

package com.paxcel.demoCoreModule.converter;


import org.springframework.stereotype.Component;


import com.paxcel.demoCoreModule.dto.UserDTO;
import com.paxcel.demoDaoModule.domain.UserInfo;




@Component
public class UserConvertor {
	
	


	public UserDTO convertToDto(UserInfo userInfo) {
		UserDTO userDTO=new UserDTO();
		
		  userDTO.setAccountNo(userInfo.getAccountNo());
		  userDTO.setAccountId(userInfo.getAccountId());
		  userDTO.setAge(userInfo.getAge());
		  userDTO.setBalance(userInfo.getBalance());
		  userDTO.setName(userInfo.getName());
		  userDTO.setPassword(userInfo.getPassword());
		  userDTO.setGender(userInfo.getGender());
		  userDTO.setUsername(userInfo.getUsername());
		
		     return userDTO;
		 }
	public UserInfo convertToBean(UserDTO userDTO) {
		
		UserInfo userInfo=new UserInfo();
		
		  userInfo.setAccountNo(userDTO.getAccountNo());
		  userInfo.setAccountId(userDTO.getAccountId());
		  userInfo.setAge(userDTO.getAge());
		  userInfo.setBalance(userDTO.getBalance());
		  userInfo.setName(userDTO.getName());
		  userInfo.setPassword(userDTO.getPassword());
		  userInfo.setGender(userDTO.getGender());
		  userInfo.setUsername(userDTO.getUsername());
		 
		     return userInfo;
		 }
}

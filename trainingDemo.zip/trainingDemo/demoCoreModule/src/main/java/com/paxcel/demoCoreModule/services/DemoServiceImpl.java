package com.paxcel.demoCoreModule.services;

import org.springframework.stereotype.Service;

import com.paxcel.demoCoreModule.services.DemoService;


@Service
public class DemoServiceImpl implements DemoService {

	public void testDemoService() {
		System.out.println("**********DemoService*******************");
	}

	
	
	

}

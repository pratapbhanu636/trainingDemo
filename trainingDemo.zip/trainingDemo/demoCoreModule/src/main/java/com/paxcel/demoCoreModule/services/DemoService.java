package com.paxcel.demoCoreModule.services;

public interface DemoService {
	
	public void testDemoService();

}

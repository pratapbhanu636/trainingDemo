package com.paxcel.demoCoreModule.converter;


import org.springframework.stereotype.Component;

import com.paxcel.demoCoreModule.dto.AddressDTO;
import com.paxcel.demoDaoModule.domain.AddressInfo;

@Component
public class AddressConvertor {
	

	
	public AddressDTO convertToDto(AddressInfo addressInfo) {
		
		AddressDTO addressDTO = new 	AddressDTO();
		
		 addressDTO.setAccountId(addressInfo.getAccountId());
		
		 addressDTO.setCityName(addressInfo.getCityName());
		 addressDTO.setStreetName(addressInfo.getStreetName());
		 addressDTO.setStateName(addressInfo.getStateName());
		 addressDTO.setZipcode(addressInfo.getZipcode());
		
		     return addressDTO;
		 }
	public AddressInfo convertToBean(AddressDTO addressDTO) {
		AddressInfo addressInfo = new AddressInfo();
		
		
		 addressInfo.setAccountId(addressDTO.getAccountId());
		
		 addressInfo.setCityName(addressDTO.getCityName());
		 addressInfo.setStreetName(addressDTO.getStreetName());
		 addressInfo.setStateName(addressDTO.getStateName());
		 addressInfo.setZipcode(addressDTO.getZipcode());
		
		     return addressInfo;
		 }
}

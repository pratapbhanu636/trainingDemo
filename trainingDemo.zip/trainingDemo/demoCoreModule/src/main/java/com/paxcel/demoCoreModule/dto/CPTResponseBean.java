package com.paxcel.demoCoreModule.dto;



public class CPTResponseBean {
	

	
	private boolean status;
	private String message;
	private String errorCode;
	private Object data;
	
	public CPTResponseBean() {}
	
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}



}


package com.paxcel.demoCoreModule.dto;

import org.springframework.stereotype.Component;

@Component
public class AddressDTO {
	private long accountId;

	private String streetName;

	private String cityName;

	private String stateName;

	private String zipcode;

	
	

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String s_name) {
		this.streetName = s_name;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String c_name) {
		this.cityName = c_name;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String state_name) {
		this.stateName = state_name;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

}

package com.paxcel.demoCoreModule.services.impl;

import org.springframework.stereotype.Service;

import com.paxcel.demoCoreModule.services.FileParser;

@Service("xlsx")
public class ExcelFileParserImpl implements FileParser{

	public void parse() {
		System.out.println("ExcelFileParserImpl");
		
	}

}

package com.paxcel.demoCoreModule.services;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paxcel.demoCoreModule.converter.AddressConvertor;
import com.paxcel.demoCoreModule.converter.FileConvertor;
import com.paxcel.demoCoreModule.converter.UserConvertor;
import com.paxcel.demoCoreModule.dto.AddressDTO;
import com.paxcel.demoCoreModule.dto.BalanceDTO;
import com.paxcel.demoCoreModule.dto.CPTResponseBean;
import com.paxcel.demoCoreModule.dto.UserDTO;
import com.paxcel.demoDaoModule.AccountDetailDao;
import com.paxcel.demoDaoModule.CsvFileWriter;
import com.paxcel.demoDaoModule.domain.AddressInfo;
import com.paxcel.demoDaoModule.domain.FileInfo;
import com.paxcel.demoDaoModule.domain.UserInfo;

@Service
public class UserService  {

	@Autowired
	AccountDetailDao accountDetailDao;
	@Autowired
	UserConvertor userConvertor;
	@Autowired
	AddressConvertor addressConvertor;
	@Autowired
	CsvFileWriter csvFileWriter;

	@Autowired
	FileConvertor fileConvertor;

	private static List<UserInfo> users;

	public List<UserInfo> findAllUsers() {

		return accountDetailDao.findAllUsers();
	}

	public void setAddressConvertor(AddressConvertor addressConvertor) {
		this.addressConvertor = addressConvertor;
	}

	public void setUserConvertor(UserConvertor userConvertor) {
		this.userConvertor = userConvertor;
	}

	public void setAccountDetailDao(AccountDetailDao accountDetailDao) {
		this.accountDetailDao = accountDetailDao;
	}

	AddressInfo addressInfo = new AddressInfo();

	public void saveDetails(UserDTO userDTO) {

		UserInfo userInfo = userConvertor.convertToBean(userDTO);

		accountDetailDao.saveAccountDetail(userInfo);
	}

	public void saveAddressDetails(AddressDTO addressDTO) {
		addressInfo = addressConvertor.convertToBean(addressDTO);
		accountDetailDao.saveAddressDetail(addressInfo);
	}

	public boolean loginCheck(UserDTO userDTO) {
		UserInfo userInfo = userConvertor.convertToBean(userDTO);

		userInfo.setAccountId(userInfo.getAccountId());

		if (userInfo.getPassword().equals(accountDetailDao.loginCheckDao(userInfo.getAccountId()))) {

			return true;

		} else {
			return false;
		}
	}

	public boolean updateValidation(BalanceDTO balanceDTO) {

		if (balanceDTO.getPassword().equals(accountDetailDao.loginCheckDao(balanceDTO.getAccountId()))) {

			return true;

		} else {
			return false;
		}
	}

	public UserDTO userDetails(UserDTO userDTO) {
		UserInfo userInfo = new UserInfo();
		userDTO = userConvertor.convertToDto(accountDetailDao.getUserDetail(userInfo, userDTO.getAccountId()));
		System.out.println(userDTO.getBalance());
		return userDTO;

	}

	public UserDTO addBalance(BalanceDTO balanceDTO) throws IOException {
		UserInfo userInfo = new UserInfo();
		UserDTO userDTO = new UserDTO();
		String filename="E:\\AddMoneyReciept.txt";
		userDTO = userConvertor.convertToDto(
				accountDetailDao.updateAddBalance(balanceDTO.getAddAmount(), balanceDTO.getAccountId(), userInfo,filename));
		return userDTO;
	}

	public UserDTO withDrawBalance(BalanceDTO balanceDTO) throws IOException {
		UserInfo userInfo = new UserInfo();
		UserDTO userDTO = new UserDTO();
		String filename="E:\\WithdrawMoneyReciept.txt";
		userDTO = userConvertor.convertToDto(accountDetailDao.updateWithdrawBalance(balanceDTO.getWithdrawAmount(),
				balanceDTO.getAccountId(), userInfo,filename));
		return userDTO;
	}

	public UserDTO userDetails1(BalanceDTO balanceDTO) {
		UserInfo userInfo = new UserInfo();
		UserDTO userDTO = new UserDTO();
		userDTO = userConvertor.convertToDto(accountDetailDao.getUserDetail(userInfo, balanceDTO.getAccountId()));

		return userDTO;

	}

	public void saveFile(FileInfo fileInfo) {

		accountDetailDao.saveFileDetail(fileInfo);
	}

	public UserInfo findById(long accountId) {

		UserInfo userInfo=new UserInfo();
		return accountDetailDao.getUserDetail(userInfo, accountId);
	}
	public void writeData()
	{
		String fileName="E:\\bhanu2.csv";
		long l = System.currentTimeMillis();
		csvFileWriter.writeCsvFile(fileName);
		System.out.println("Printing Data");
		long p = System.currentTimeMillis();
		long j = p - l;
		j = j / 1000;
		System.out.println((int) j + " s");
	}
	
	
	
	public void writeCPT(int Id)
	{
		
		CPTResponseBean cptResponseBean=new CPTResponseBean();
		if(Id==0)
		{
			cptResponseBean.setStatus(false);
			cptResponseBean.setMessage("CPT");
		}
		if(Id==1)
		{
			cptResponseBean.setStatus(false);
			cptResponseBean.setMessage("BlackDiomand");
		}
		
		if(Id==2)
		{
			cptResponseBean.setStatus(true);
			cptResponseBean.setMessage("Success");
		}
		
	}
	
}

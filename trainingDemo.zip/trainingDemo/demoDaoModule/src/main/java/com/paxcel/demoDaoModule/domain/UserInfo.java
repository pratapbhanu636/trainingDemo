package com.paxcel.demoDaoModule.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
@Entity
@Table(name = "userInfo")
public class UserInfo implements Serializable {

	@XmlAttribute
	@Id
	@Column(name = "accountid")
	private long accountId;

	@XmlElement
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accountNo")
	private long accountNo;
	@XmlElement
	@Column(name = "name")
	private String name;
	@XmlElement
	@Column(name = "balance")
	private double balance;
	@XmlElement
	@Column(name = "age")
	private int age;
	@XmlElement
	@Column(name = "gender")
	private String gender;
	@XmlElement
	@Column(name = "username")
	private String username;
	@XmlElement
	@Column(name = "password")
	private String password;

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public double getBalance() {
		return balance;
	}

	public String getGender() {
		return gender;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {

		return password;
	}

	public void setUsername(String username) {

		this.username = username;

	}

	public void setPassword(String password) {

		this.password = password;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
}
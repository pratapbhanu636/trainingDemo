package com.paxcel.demoDaoModule;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.paxcel.demoDaoModule.domain.UserInfo;

@Repository
public class CsvFileWriter  {
	@Autowired
	private SessionFactory sessionFactory;
	

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	// Delimiter used in CSV file

	private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_HEADER = "AccountNo,AccountId,Age,Balance,Gender,Name";

	
	@Transactional
	public void writeCsvFile(String fileName) {
		Session session = this.sessionFactory.getCurrentSession();
		FileWriter fileWriter = null;

		
		try {

			fileWriter = new FileWriter(fileName);
			 fileWriter.append(FILE_HEADER.toString());

			// Write the CSV file header

			// Add a new line separator after the header

			fileWriter.append(NEW_LINE_SEPARATOR);

			// Write a new student object list to the CSV file
			 Query q = session.createQuery("from UserInfo ");
			 List<UserInfo> users= (List<UserInfo>)q.list();
			

			for (UserInfo userInfo : users) {

				fileWriter.append(String.valueOf(userInfo.getAccountNo()));

				fileWriter.append(COMMA_DELIMITER);

				fileWriter.append(String.valueOf(userInfo.getAccountId()));

				fileWriter.append(COMMA_DELIMITER);

				fileWriter.append(String.valueOf(userInfo.getAge()));

				fileWriter.append(COMMA_DELIMITER);

				fileWriter.append(String.valueOf(userInfo.getBalance()));

				fileWriter.append(COMMA_DELIMITER);

				fileWriter.append(String.valueOf(userInfo.getGender()));
				fileWriter.append(COMMA_DELIMITER);

				fileWriter.append(String.valueOf(userInfo.getName()));

				fileWriter.append(NEW_LINE_SEPARATOR);

			}

			System.out.println("CSV file was created successfully !!!");

		} catch (Exception e) {

			System.out.println("Error in CsvFileWriter !!!");

			e.printStackTrace();

		} finally {

			try {

				fileWriter.flush();

				fileWriter.close();

			} catch (IOException e) {

				e.printStackTrace();

			}
		}

		}

	

	

}

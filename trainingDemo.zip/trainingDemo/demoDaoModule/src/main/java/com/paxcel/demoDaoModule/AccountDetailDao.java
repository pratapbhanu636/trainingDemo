package com.paxcel.demoDaoModule;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.paxcel.demoDaoModule.domain.AddressInfo;
import com.paxcel.demoDaoModule.domain.FileInfo;
import com.paxcel.demoDaoModule.domain.UserInfo;

@Repository
public class AccountDetailDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveAccountDetail(UserInfo userInfo) {
		// TODO Auto-generated constructor stub
		Session session = this.sessionFactory.getCurrentSession();

		session.persist(userInfo);

	}

	@Transactional
	public void saveAddressDetail(AddressInfo addressInfo) {
		// TODO Auto-generated constructor stub
		Session session = this.sessionFactory.getCurrentSession();
		session.save(addressInfo);
	}

	@Transactional
	public String loginCheckDao(long accountId) {
		Session session = this.sessionFactory.getCurrentSession();

		String result = (String) session.createCriteria(UserInfo.class).add(Restrictions.eq("accountId", accountId))
				.setProjection(Property.forName("password")).uniqueResult();

		return result;

	}

	@Transactional
	public UserInfo updateAddBalance(double addAmount, long accountId, UserInfo userInfo, String fileName)
			throws IOException {

		Session session = this.sessionFactory.getCurrentSession();
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date today = (Date) Calendar.getInstance().getTime();
		String reportDate = df.format(today);
		String dateToPrintToFile = reportDate;
		double oldBalance;
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
		/*
		 * Integer oldBalance = (Integer) session.createCriteria(UserInfo.class)
		 * .add(Restrictions.eq("accountId",
		 * accountId)).setProjection(Property.forName("balance")).uniqueResult()
		 * ;
		 */
		Query query = session.createQuery("from UserInfo where id= :id");
		query.setLong("id", accountId);
		userInfo = (UserInfo) query.uniqueResult();
		oldBalance = userInfo.getBalance();
		Long accountNo=userInfo.getAccountNo();
		String name=userInfo.getName();
		writer.write("Name");
		writer.append(' ');
		writer.write(name);
		writer.newLine();
		writer.write("Account No ");
		writer.append(' ');
		writer.write(accountNo.toString());
		writer.newLine();
		writer.append("OldBalance -");
		writer.append(' ');
		writer.append(String.valueOf(oldBalance));
		writer.newLine();
        
		double updateBalance = oldBalance + addAmount;
		writer.append("NewBalance - ");
		writer.append(' ');
		writer.append(String.valueOf(updateBalance));
		writer.newLine();
		Query query2 = session.createQuery("update UserInfo u set u.balance = :newbalance where u.accountId = :id");
		query2.setDouble("newbalance", updateBalance);
		query2.setLong("id", accountId);
		int result = query2.executeUpdate();
		writer.append("NewBalance Updated ");
		writer.newLine();
		writer.write(dateToPrintToFile);
		writer.newLine();
		writer.close();
		return userInfo;

	}

	@Transactional
	public UserInfo updateWithdrawBalance(double withdrawAmount, long accountId, UserInfo userInfo, String fileName)
			throws IOException {
		Session session = this.sessionFactory.getCurrentSession();
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date today = (Date) Calendar.getInstance().getTime();
		String reportDate = df.format(today);
		String dateToPrintToFile = reportDate;
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
		double oldBalance;

		Query query = session.createQuery("from UserInfo where id= :id");
		query.setLong("id", accountId);
		userInfo = (UserInfo) query.uniqueResult();
		oldBalance = userInfo.getBalance();
		Long accountNo=userInfo.getAccountNo();
		String name=userInfo.getName();
		writer.write("Name");
		writer.append(' ');
		writer.write(name);
		writer.newLine();
		writer.write("Account No ");
		writer.append(' ');
		writer.write(accountNo.toString());
		writer.newLine();
		writer.append("OldBalance - ");
		writer.append(' ');
		writer.append(String.valueOf(oldBalance));
		writer.newLine();
		double updateBalance = oldBalance - withdrawAmount;
		writer.append("NewBalance - ");
		writer.append(' ');
		writer.append(String.valueOf(updateBalance));
		writer.newLine();
		System.out.println("Your Update balance is " + updateBalance);
		Query query2 = session.createQuery("update UserInfo u set u.balance = :newbalance where u.accountId = :id");
		query2.setDouble("newbalance", updateBalance);
		query2.setLong("id", accountId);
		int result = query2.executeUpdate();
		writer.append("NewBalance Updated ");
		writer.newLine();
		writer.write(dateToPrintToFile);
		writer.newLine();
		writer.close();
		return userInfo;
	}

	@Transactional
	public UserInfo getUserDetail(UserInfo userInfo, long accountId) {
		Session session = this.sessionFactory.getCurrentSession();

		Query query = session.createQuery("from UserInfo where id= :id");
		query.setLong("id", accountId);
		userInfo = (UserInfo) query.uniqueResult();

		return userInfo;
	}

	@Transactional
	public void saveFileDetail(FileInfo fileInfo) {
		// TODO Auto-generated constructor stub
		Session session = this.sessionFactory.getCurrentSession();

		session.save(fileInfo);

	}

	@Transactional
	public List<UserInfo> findAllUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		Query q = session.createQuery("from UserInfo ");
		List<UserInfo> users = (List<UserInfo>) q.list();
		return users;
	}
}

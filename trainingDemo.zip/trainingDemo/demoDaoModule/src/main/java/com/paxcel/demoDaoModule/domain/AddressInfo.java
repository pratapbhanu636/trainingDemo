package com.paxcel.demoDaoModule.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity(name = "addressinfo")
public class AddressInfo {

	@Id
	
	@Column(name = "accountId")

	private long accountId;

	
	@Column(name = "streetName")
	private String streetName;
	@Column(name = "cityName")
	private String cityName;
	@Column(name = "stateName")
	private String stateName;
	@Column(name = "zipcode")
	private String zipcode;

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String s_name) {
		this.streetName = s_name;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String c_name) {
		this.cityName = c_name;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String state_name) {
		this.stateName = state_name;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

}

package com.paxcel.demoDaoModule.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fileInfo")
public class FileInfo {
	@Id
	@GeneratedValue
	@Column(name = "accountId")
	private long accountId;
	@Column(name = "FILE_NAME")

	private String fileName;
	@Column(name = "FILE_DATA")
	private byte[] data;

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long id) {
		this.accountId = accountId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}
}

package com.paxcel.demoWebModule.configuration.spring.securityConfig;


import org.springframework.security.web.context.*;

public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
	 
}
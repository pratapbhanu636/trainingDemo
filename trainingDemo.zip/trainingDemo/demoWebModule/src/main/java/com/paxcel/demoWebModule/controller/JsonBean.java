package com.paxcel.demoWebModule.controller;

public class JsonBean {
	private String Id;
	private String Name;
	private String AccountIds;

	
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}


 
	public void setId(String Id) {
		this.Id = Id;
	}
 
	public void setAccountIds(String AccountIds) {
		this.AccountIds = AccountIds;
	}
 
	public String getId() {
		return Id;
	}
 
	public String getAccountIds() {
		return AccountIds;
	}
}

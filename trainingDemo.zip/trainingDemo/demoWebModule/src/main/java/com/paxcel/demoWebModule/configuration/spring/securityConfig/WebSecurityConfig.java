package com.paxcel.demoWebModule.configuration.spring.securityConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.authentication.builders.*;  
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.*;

@EnableWebSecurity
@ComponentScan(basePackages = { "com.paxcel.demoWebModule", "com.paxcel.demoCoreModule", "com.paxcel.demoDaoModule" })
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("bhanu").password("{noop}123456").roles("USER");
		auth.inMemoryAuthentication().withUser("admin").password("{noop}nimda").roles("ADMIN");

	}

	// .csrf() is optional, enabled by default, if using
	// WebSecurityConfigurerAdapter constructor
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests().antMatchers("/user/userLogin").access("hasRole('USER')").antMatchers("/user")
				.permitAll()

				.and().formLogin();

		http.csrf().disable();
	}

}
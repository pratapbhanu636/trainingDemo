package com.paxcel.demoWebModule.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.paxcel.demoCoreModule.dto.AddressDTO;
import com.paxcel.demoCoreModule.dto.BalanceDTO;
import com.paxcel.demoCoreModule.dto.UserDTO;
import com.paxcel.demoCoreModule.services.FileParser;
import com.paxcel.demoCoreModule.services.UserService;
import com.paxcel.demoDaoModule.domain.FileInfo;

@Controller
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	Map<String, FileParser> parserList;

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	

	@RequestMapping(value = "/newRegistration", method = RequestMethod.GET)
	public String viewRegistration(Map<String, Object> model) {
		UserDTO userDTO = new UserDTO();
		model.put("userDTO", userDTO);

		/*
		 * List<String> professionList = new ArrayList<String>();
		 * professionList.add("Developer"); professionList.add("Designer");
		 * professionList.add("IT Manager"); model.put("professionList",
		 * professionList);
		 */
		/* req.setAttribute("professionList",professionList); */
		return "userRegistration";
	}

	@RequestMapping(value = "/addressRegistration", method = RequestMethod.GET)
	public String addressRegistration(Map<String, Object> model) {
		AddressDTO addressDTO = new AddressDTO();
		model.put("addressDTO", addressDTO);

		return "addressRegistration";
	}

	@RequestMapping(value = "/userLogin", method = RequestMethod.GET)
	public String userLogin(Map<String, Object> model) {
		UserDTO userDTO = new UserDTO();
		model.put("userDTO", userDTO);

		return "logInPage";
	}
	@RequestMapping(value = "/userRegistered", method = RequestMethod.GET)
	public String userRegister(Map<String, Object> model) {
		UserDTO userDTO = new UserDTO();
		model.put("userDTO", userDTO);

		return "userRegistered";
	}

	@RequestMapping(value = "/updateBalance", method = RequestMethod.GET)
	public String updateBalance(Map<String, Object> model) {
		BalanceDTO balanceDTO = new BalanceDTO();
		model.put("balanceDTO", balanceDTO);

		return "balanceUpdate";
	}

	@RequestMapping(value = "/uploadFile")
	public String uploadFile() {

		return "uploadFile";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processRegistration(@ModelAttribute("userDTO") UserDTO userDTO, Model model) {

		// registration logic here...
		userDTO.getAddressDTO().setAccountId(userDTO.getAccountId());
		userService.saveAddressDetails(userDTO.getAddressDTO());
		userService.saveDetails(userDTO);
		model.addAttribute("userDTO", userService.userDetails(userDTO));
		

		 return "redirect:/user/userRegistered";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginProcess(@ModelAttribute("userDTO") UserDTO userDTO, Model model) {

		if (userService.loginCheck(userDTO)) {
			
			model.addAttribute("userDTO", ((UserService) userService).userDetails(userDTO));
			ModelAndView modelAndView = new ModelAndView("loginSuccessful");

			return modelAndView;
		}

		else {

			ModelAndView modelAndView = new ModelAndView("loginFailed");

			return modelAndView;
		}

	}
	

	@RequestMapping(value = "/registerAddress", method = RequestMethod.POST)
	public ModelAndView processRegistration(@ModelAttribute("addressDTO") AddressDTO addressDTO,
			Map<String, Object> model) {

		// registration logic here...

		// for testing

		userService.saveAddressDetails(addressDTO);
		ModelAndView modelAndView = new ModelAndView("addressRegistered");
		modelAndView.addAllObjects(model);
		return modelAndView;
	}

	@RequestMapping(value = "/addBalanceUpdated", method = RequestMethod.POST)
	public String addBalanceUpdated(@ModelAttribute("balanceDTO") BalanceDTO balanceDTO, Model model) throws IOException {
		
	   
		

		if (userService.updateValidation(balanceDTO)) {
			userService.addBalance(balanceDTO);
			
			model.addAttribute("userDTO", userService.userDetails1(balanceDTO));
			
		
          
			
			 return "redirect:/user/addUpdatedBalanceGet";
			
		} else {
			

			return "loginFailed";
		}
	    
	}
	@RequestMapping(value = "/addUpdatedBalanceGet", method = RequestMethod.GET)
	public String addBalanceUpdatedGet() throws IOException {
		
		return "addUpdatedBalance";
	}
	
		

	@RequestMapping(value = "/withdrawBalanceUpdated", method = RequestMethod.POST)
	public String withdrawBalanceUpdated(@ModelAttribute("balanceDTO") BalanceDTO balanceDTO,HttpServletResponse response, Model model) throws IOException {
		
	

		if (userService.updateValidation(balanceDTO)) {
			userService.withDrawBalance(balanceDTO);
			model.addAttribute("userDTO", userService.userDetails1(balanceDTO));
			

			 return "redirect:/user/withdrawUpdatedBalanceGet";
		} else {
			

			return "loginFailed";
		}
	}
	@RequestMapping(value = "/withdrawUpdatedBalanceGet", method = RequestMethod.GET)
	public String withdrawBalanceUpdatedGet() throws IOException {
		
		return "withdrawUpdatedBalance";
	}
	

	@RequestMapping(value = "/paxcelBank")
	public String paxcelBank() {

		return "paxcelBank";
	}

	@RequestMapping(value = "/contact")
	public String contact() {

		return "contact";
	}

	@RequestMapping(value = "/savefile", method = RequestMethod.POST)
	public String handleFileUpload(HttpServletRequest request, @RequestParam CommonsMultipartFile[] fileUpload)
			throws Exception {

		if (fileUpload != null && fileUpload.length > 0) {
			for (CommonsMultipartFile aFile : fileUpload) {

				System.out.println("Saving file: " + aFile.getOriginalFilename());

				FileInfo uploadFile = new FileInfo();
				uploadFile.setFileName(aFile.getOriginalFilename());
				uploadFile.setData(aFile.getBytes());
				userService.saveFile(uploadFile);
			}
		}

		return "upload-success";
	}

	@RequestMapping(value = "/download/{type}", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse response, @PathVariable("type") String type) throws IOException {
		
	      String ADD_RECIEPT_FILE = "E:\\AddMoneyReciept.txt";
		  String WITHDRAW_RECIEPT__FILE = "E:\\WithdrawMoneyReciept.txt";
        
		  
		File file = null;

		if (type.equalsIgnoreCase("Add")) {
			
			file = new File(ADD_RECIEPT_FILE);
			
		} else {
			
			file = new File(WITHDRAW_RECIEPT__FILE);
		}

		if (!file.exists()) {
			String errorMessage = "Sorry. The file you are looking for does not exist";
			System.out.println(errorMessage);
			OutputStream outputStream = response.getOutputStream();
			outputStream.write(errorMessage.getBytes(Charset.forName("UTF-8")));
			outputStream.close();
			return;
		}

		String mimeType = URLConnection.guessContentTypeFromName(file.getName());
		if (mimeType == null) {
			System.out.println("mimetype is not detectable, will take default");
			mimeType = "application/octet-stream";
		}

		System.out.println("mimetype : " + mimeType);

		response.setContentType(mimeType);

		/*
		 * "Content-Disposition : inline" will show viewable types [like
		 * images/text/pdf/anything viewable by browser] right on browser while
		 * others(zip e.g) will be directly downloaded [may provide save as
		 * popup, based on your browser setting.]
		 */
		//response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() + "\""));

		/*
		 * "Content-Disposition : attachment" will be directly download, may
		 * provide save as popup, based on your browser setting
		 */
		 response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
		

		response.setContentLength((int) file.length());

		InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

		// Copy bytes from source to destination(outputstream in this example),
		// closes both streams.
		FileCopyUtils.copy(inputStream, response.getOutputStream());
	}
	
	@RequestMapping(value = "/test/test")
	public String test() {
		String fileName = "test.xlsx";
		String fileExtension = fileName.substring(fileName.indexOf('.')+1, fileName.length());
		System.out.println("fileExtension = "+fileExtension);
		parserList.get(fileExtension).parse();
		return "paxcelBank";
	}

}

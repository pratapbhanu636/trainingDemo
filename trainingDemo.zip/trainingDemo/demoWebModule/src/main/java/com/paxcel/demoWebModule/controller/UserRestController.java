package com.paxcel.demoWebModule.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paxcel.demoCoreModule.dto.CPTResponseBean;
import com.paxcel.demoCoreModule.services.UserService;
import com.paxcel.demoDaoModule.domain.UserInfo;

@RestController
@RequestMapping(value = "/rest")
public class UserRestController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/test", method = RequestMethod.GET)

	public String example() throws Exception {

		return "$5";
	}

	@RequestMapping(value = "/rest/", method = RequestMethod.GET)
	public ResponseEntity<List<UserInfo>> listAllUsers() {
		List<UserInfo> users = userService.findAllUsers();
		if (users.isEmpty()) {
			return new ResponseEntity<List<UserInfo>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<UserInfo>>(users, HttpStatus.OK);
	}

	@RequestMapping(value = "/restUser/{accountId}", headers = "Accept=application/json", method = RequestMethod.GET)
	public ResponseEntity<UserInfo> getUser(@PathVariable("accountId") long accountId) {
		System.out.println("Fetching User with id " + accountId);
		UserInfo user = userService.findById(accountId);
		if (user == null) {
			System.out.println("User with id " + accountId + " not found");
			return new ResponseEntity<UserInfo>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserInfo>(user, HttpStatus.OK);
	}

	@RequestMapping(value = "/myUser/{accountId}", headers = "Accept=application/xml", method = RequestMethod.GET)
	public ResponseEntity<UserInfo> getUser1(@PathVariable("accountId") long accountId) {
		System.out.println("Fetching User with id " + accountId);
		UserInfo user = userService.findById(accountId);
		if (user == null) {
			System.out.println("User with id " + accountId + " not found");
			return new ResponseEntity<UserInfo>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserInfo>(user, HttpStatus.OK);
	}

	/*
	 * @RequestMapping(value = "/newUser/", method = RequestMethod.POST) public
	 * ResponseEntity<Void> createUser(@RequestBody UserDTO userDTO,
	 * UriComponentsBuilder ucBuilder,Model model) {
	 * System.out.println("Creating User " + userDTO.getName());
	 * 
	 * userDTO.getAddressDTO().setAccountId(userDTO.getAccountId());
	 * userService.saveAddressDetails(userDTO.getAddressDTO());
	 * userService.saveDetails(userDTO); model.addAttribute("userDTO",
	 * userService.userDetails(userDTO));
	 * 
	 * 
	 * return new ResponseEntity<Void>(HttpStatus.CREATED); }
	 */

}

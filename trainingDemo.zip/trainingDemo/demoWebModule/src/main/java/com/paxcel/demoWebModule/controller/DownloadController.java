package com.paxcel.demoWebModule.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.paxcel.demoCoreModule.dto.CPTResponseBean;
import com.paxcel.demoCoreModule.services.UserService;
import com.paxcel.demoDaoModule.domain.UserInfo;

@RestController
@RequestMapping(value = "/downloadZip")
public class DownloadController extends HttpServlet {
	

	@Autowired
	UserService userService;
	private static final long serialVersionUID = -7767828383799037391L;

	

		

		@RequestMapping(value = "/download/{Id}", method = RequestMethod.GET,produces="application/zip")
		 public byte[] zipFiles(HttpServletResponse response) throws IOException{
	        //setting headers
			//userService.writeData();
			/* List<UserInfo> users = userService.findAllUsers();
		        ObjectMapper mapper = new ObjectMapper();
				 mapper.writeValue(new File("E:\\dataOne.json"), users);*/
			//System.out.println("Fetching User with id " + 125);
			//UserInfo user = userService.findById(125);
			 //ObjectMapper mapper = new ObjectMapper();
			/* ObjectWriter writer = mapper.writer(new DefaultPrettyPrinter());*/
			// mapper.writeValue(new File("E:\\dataOne.json"), user);
				
	        response.setStatus(HttpServletResponse.SC_OK);
	        response.addHeader("Content-Disposition", "attachment; filename=\"test.zip\"");

	        //creating byteArray stream, make it bufforable and passing this buffor to ZipOutputStream
	        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream);
	        ZipOutputStream zipOutputStream = new ZipOutputStream(bufferedOutputStream);
	      
	       

	        //simple file list, just for tests
	        ArrayList<File> files = new ArrayList<File>(2);
	        files.add(new File("E:\\Batch682\\portfolio.json"));
	        files.add(new File("E:\\Batch682\\accounts 1-250.json"));
	        files.add(new File("E:\\Batch682\\accounts 251-500.json"));
	        System.out.println("--Adding File--");
		      
	        

	        //packing files
	        for (File file : files) {
	            //new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
	            zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
	            FileInputStream fileInputStream = new FileInputStream(file);

	            IOUtils.copy(fileInputStream, zipOutputStream);

	            fileInputStream.close();
	            zipOutputStream.closeEntry();
	        }

	        if (zipOutputStream != null) {
	            zipOutputStream.finish();
	            zipOutputStream.flush();
	            IOUtils.closeQuietly(zipOutputStream);
	        }
	        IOUtils.closeQuietly(bufferedOutputStream);
	        IOUtils.closeQuietly(byteArrayOutputStream);
	        return byteArrayOutputStream.toByteArray();
	    }
		


		@RequestMapping(value = "/CPTUser/{Id}",  method = RequestMethod.GET)
		public CPTResponseBean getUser(@PathVariable("Id") int Id) {
			System.out.println("Fetching User with id " + Id);
			CPTResponseBean cptResponseBean=new CPTResponseBean();
			if(Id==0)
			{
				cptResponseBean.setStatus(false);
				cptResponseBean.setMessage("$$$$$$$");
			}
			else if(Id==1)
			{
				cptResponseBean.setStatus(false);
				cptResponseBean.setMessage("BLACK_DIAMOND");
			}
			
			else if(Id==2)
			{
				cptResponseBean.setStatus(true);
				cptResponseBean.setMessage("Success");
			}
		
			return cptResponseBean; 
		}

	}



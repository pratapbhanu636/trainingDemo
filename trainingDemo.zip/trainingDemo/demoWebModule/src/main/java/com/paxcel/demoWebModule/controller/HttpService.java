package com.paxcel.demoWebModule.controller;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;

public class HttpService {
	
	//private static Logger log = Logger.getLogger(HttpService.class);
	
	private static HttpService httpService = null;
	private HttpClient httpClient =  null;
	
	private HttpService()  {
		int timeout = 20;
		RequestConfig config = RequestConfig.custom()
		  .setConnectTimeout(timeout * 1000)
		  .setConnectionRequestTimeout(timeout * 1000)
		  .setSocketTimeout(timeout * 1000).build();
		httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
	}
	
	public static HttpService getInstance()  {
		if (httpService == null) {
			synchronized(HttpService.class){
				if (httpService == null) {
					httpService = new HttpService();
				}
			}
        }
        return httpService;
	}

	public HttpClient getHttpClient() {
		return httpClient;
	}
	
	/*public BlackDiamondResponse getBlackDiamondAccountToken(String userName, String password){
		
		BlackDiamondResponse blackDiamondResponse = new BlackDiamondResponse();
		
		*//**
		 * TO DO : All below key's value will be fetched from Data Base
		 *//*
		
		HttpPost post = new HttpPost("https://apisandbox.bdreporting.com/issue/oauth2/token");
		post.setHeader("Content-Type", "application/x-www-form-urlencoded");

		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair(Constants.GRANT_TYPE_KEY, "password"));
		urlParameters.add(new BasicNameValuePair(Constants.CLIENT_ID_KEY, "Chaikin_Sandbox_Api"));
		urlParameters.add(new BasicNameValuePair(Constants.CLIENT_SECRET_KEY, "D7ii6E9FrdV2P4TQSZrDJu2Uk7rnVMb80CAe97FVHv9zIrKR0oKNFo3/MAxVFFGvzPF2/UDHLqx4Nz7F9lFXeQ=="));
		urlParameters.add(new BasicNameValuePair(Constants.USERNAME_KEY, userName));//"chaikin_apiuser"
		urlParameters.add(new BasicNameValuePair(Constants.PASSWORD_KEY, password));//"Password1234"
		try {
			post.setEntity(new UrlEncodedFormEntity(urlParameters));
			HttpResponse response = httpClient.execute(post);
			String responseAsString = EntityUtils.toString(response.getEntity());
			Gson gson = JsonUtility.getGsonInstance();	
			blackDiamondResponse = gson.fromJson(responseAsString, BlackDiamondResponse.class);
			if(response.getStatusLine().getStatusCode()==200){
				blackDiamondResponse.setIsSuccess(true);
			}
		}catch(Exception ex) {	
			log.error("Exception in getBlackDiamondAccountToken() : ", ex); 
			blackDiamondResponse.setError(Constants.Error.BLACK_DIAMOND_SERVER_ERROR.getErrorCode());
			blackDiamondResponse.setError_description(Constants.Error.BLACK_DIAMOND_SERVER_ERROR.getMessage());
		}
		return blackDiamondResponse;
	}*/
}

package com.paxcel.demoWebModule.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;

import com.paxcel.demoDaoModule.domain.UserInfo;




public class TestClient implements Callable {
	
	private Integer Id;
	public TestClient(Integer Id)
	{
		this.Id=Id;
	}
	
	private static HttpService httpService = HttpService.getInstance();
  
	
	  public Integer call()
	  {
		  
		  try{
        	  String url="http://localhost:8080/demoWeb/downloadZip/download/Id";
     		 
     		 HttpGet httpget = new HttpGet(url);
     		 System.out.println("Getting Response");
              HttpResponse response = httpService.getHttpClient().execute(httpget);
              System.out.println("Response");
              HttpEntity entity = response.getEntity();
              if (entity != null) {
                  long len = entity.getContentLength();
                  InputStream is = entity.getContent();
                  System.out.println("Creating File");
                  String filePath = "E:\\sample" + Id + ".zip";
                  FileOutputStream fos = new FileOutputStream(new File(filePath));
                  int inByte;
                  while((inByte = is.read()) != -1)
                       fos.write(inByte);
                  is.close();
                  fos.close();
                 
                  
                  String destDir = "E:\\output" + Id;
                  
                  unzip(filePath, destDir);
              }
          }catch(Exception ex){
        	  ex.printStackTrace();
          }
          
	  return Id;
	  }

	public static void main(String[] args) throws ClientProtocolException, IOException, ExecutionException {

		/*UserInfo userInfo = new UserInfo();

		 ObjectMapper mapper = new ObjectMapper();
		 mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		 userInfo = mapper.readValue(new FileInputStream("E:\\dataOne.json"), UserInfo.class );
		 System.out.println("AccountId:"+userInfo.getAccountId()+", Name  "+ userInfo.getName());
		 */
	    ExecutorService executor = Executors.newFixedThreadPool(5);
	    ExecutorService executor2 = Executors.newFixedThreadPool(10);
	    List<Future<Integer>> list2 = new ArrayList<Future<Integer>>();
	    List<Future<Integer>> list = new ArrayList<Future<Integer>>();
        for (Integer i = (int) 125; i < 130; i++) {
            Callable<Integer> worker = new TestClient(i);
            Future<Integer> submit = executor.submit(worker);
            list.add(submit);
            Callable<Integer> worker2 = new TestClient2(i);
            Future<Integer> submit2 = executor2.submit(worker2);
            list2.add(submit2);
        }
        
      
       
       
		
        
      /*  for (Future<Long> future : list) {
            try {
                
                System.out.println(future.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            } 
        }*/
	}
	  private static void unzip(String zipFilePath, String destDir) {
	        File dir = new File(destDir);
	        // create output directory if it doesn't exist
	        if(!dir.exists()){
	        	dir.mkdirs();
	        }
	        FileInputStream fis;
	        //buffer for read and write data to file
	        byte[] buffer = new byte[1024];
	        try {
	            fis = new FileInputStream(zipFilePath);
	            ZipInputStream zis = new ZipInputStream(fis);
	            ZipEntry ze = zis.getNextEntry();
	            while(ze != null){
	                String fileName = ze.getName();
	                File newFile = new File(destDir + File.separator + fileName);
	                System.out.println("Unzipping to "+newFile.getAbsolutePath());
	                //create directories for sub directories in zip
	                new File(newFile.getParent()).mkdirs();
	                FileOutputStream fos = new FileOutputStream(newFile);
	                int len;
	                while ((len = zis.read(buffer)) > 0) {
	                fos.write(buffer, 0, len);
	                }
	                fos.close();
	                //close this ZipEntry
	                zis.closeEntry();
	                ze = zis.getNextEntry();
	            }
	            //close last ZipEntry
	            zis.closeEntry();
	            zis.close();
	            fis.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
	    }
}

package com.paxcel.demoWebModule.controller;

public class Test {
	
	public static void main(String[] args) {
		
		String fileName = "test.xlsx";
		String fileExtension = fileName.substring(fileName.indexOf('.')+1, fileName.length());
		System.out.println("fileExtension = "+fileExtension);
	}

}

package com.paxcel.demoWebModule.controller;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.concurrent.Callable;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class TestClient2 implements Callable {
	
	private Integer Id;
	public TestClient2(Integer Id)
	{
		this.Id=Id;
	}
	
	public Integer call()
	{
	  	
		
		JsonBean jsonBean = new JsonBean();
  	
  		Gson gson = new GsonBuilder().setPrettyPrinting().create();
  	  try{ Writer writer = new FileWriter("E:\\Parsed" + Id + ".json");
  	  
  	
  	 
      try {
          InputStream is = new FileInputStream("E:\\output"+Id+"\\portfolio.json");
           System.out.println("Reading");
           
          // Create JsonReader from Json.
          JsonReader reader = Json.createReader(is);
          System.out.println("jsonReader");

          // Get the JsonObject structure from JsonReader.
          JsonObject obj = reader.readObject();
         

          // read integer 
          JsonArray results = obj.getJsonArray("Portfolios");
               for (JsonObject result : results.getValuesAs(JsonObject.class)) {
              	 
                  
                   jsonBean.setId(result.getJsonString("Id").toString());
                 
                  
                   jsonBean.setName(result.getJsonString("Name").toString());
                 
                   jsonBean.setAccountIds(result.getJsonArray("AccountIds").toString());
                
            		gson.toJson(jsonBean, writer);
                    }
             
       	
                
                  
      } catch (Exception e) {
          System.out.println("Failed: " + e.getMessage());
          e.printStackTrace();
      }
     
     
        }
        catch(IOException ex) {
          
            // Or we could just do this:
             ex.printStackTrace();
        }
    
  	   return Id;
		
	}
	
}
